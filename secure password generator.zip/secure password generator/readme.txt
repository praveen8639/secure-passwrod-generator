Secure Password Generator : 

A secure password generator is a tool designed to create strong, random passwords that enhance the security of user accounts and sensitive information.

Secure password generators create passwords that include a mix of uppercase and lowercase letters, numbers, and special characters. This complexity makes it harder for attackers to guess or crack the password. Many security experts recommend using passwords that are at least 8-16 characters long. A password generator can easily create long passwords that meet this requirement. Unlike passwords created by users, which may be based on easily guessable information (like birthdays or common words), a secure password generator produces truly random passwords, making them more difficult to predict.
Some generators allow users to customize their passwords based on specific criteria, such as length, inclusion of certain character types, or exclusion of similar-looking characters (like 'l' and '1').Using a password generator saves time and effort in creating secure passwords, especially when managing multiple accounts. It can also reduce the likelihood of reusing passwords across different sites.

Overall, utilizing a secure password generator is an effective way to enhance personal cybersecurity and protect sensitive information from unauthorized access.


Follow the steps to generate a secure password :

Step 1 : Open the application.
Step 2 : Select the length of the password to be generated.
Step 3 : Select the uppercase letters.
Step 4 : Select the lowercase letters.
Step 5 : Select the numbers.
Step 6 : Select the symbols.
Step 7 : Now, Click on generate password.
Step 8 : The password will be displayed on console.
Step 9 : Thus, This is an secure password that is generated to user.
Step 10 : Similarly many such passwords can be generated through it.

Note : From Step 3 to Step 6 by enabling or using them help to generate a strong and             
       secure password.

Project Structure : 
-------> index html file
-------> main css file
-------> main js file